<?php 
 
    include_once("Connection.php"); 
 
	if(!empty($_POST['Location']) && !empty($_POST['Dev_name']) && !empty($_POST['Dev_Id']) && !empty($_POST['Status']))  
	{ 
        $location = $_POST['Location'];
        $devname=$_POST['Dev_name'];
		$devid = $_POST['Dev_Id'];
		$status=$_POST['Status'];
       
		
		$sql="SELECT * From Command WHERE Location='$location' AND Dev_name='$devname' AND Dev_Id='$devid' AND Status='$status'";
		
		$rs=mysqli_fetch_array(mysqli_query($conn,$sql));
		
		if(isset($rs))
		{
			echo "Already".$status;
		}
		
		else
		{
            echo "success"; 
        } 
			 
     }
		mysqli_close($conn);	
	
?>