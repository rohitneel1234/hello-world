<?PHP 
    include_once("Connection.php"); 
    if( isset($_POST['Mobile_Number'])) { 
        $mobilenumber= $_POST['Mobile_Number'];
        
        $query = "SELECT Mobile_Number FROM Registration". 
        " WHERE Mobile_Number= '$mobilenumber'"; 
		
        $result = mysqli_query($conn, $query);
		
		if($result->num_rows > 0){
            if(isset($_POST['Mobile_Number'])){ 
                echo "success"; 
            }
		}	 
         else{ 
            echo "Login Failed <br/>"; 
        }

    } 
?>