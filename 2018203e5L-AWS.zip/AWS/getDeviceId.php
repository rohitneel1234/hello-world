<?php 
 
require_once('Connection.php');
		
$sql = "SELECT DISTINCT Dev_Id FROM Command order by Dev_Id";

$r = mysqli_query($conn,$sql);

$result2 = array();

while($row = mysqli_fetch_array($r)){

 array_push($result2,array(

 'Dev_Id'=>$row['Dev_Id']
 ));

}
echo json_encode(array('result2'=>$result2));

mysqli_close($conn);
	
?>