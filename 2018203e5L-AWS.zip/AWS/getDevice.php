<?php 
 
require_once('Connection.php');

$sql ="SELECT DISTINCT Dev_name FROM Command";

$r = mysqli_query($conn,$sql);

$result1= array();

while($row = mysqli_fetch_array($r)){

 array_push($result1,array(

 'Dev_name'=>$row['Dev_name']
 ));

}
//header('Content-Type: application/json; Charset=UTF-8');

echo json_encode(array('result1'=>$result1));

mysqli_close($conn);
	
?>