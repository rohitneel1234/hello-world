<?PHP 
    include_once("Connection.php"); 
    if(!empty($_POST['Uname']) && !empty($_POST['Mobile_Number']) && !empty($_POST['Password']) ) { 
	
        $uname = $_POST['Uname'];
        $umobile=$_POST['Mobile_Number'];
		$upassword = $_POST['Password'];
		
		$sql="SELECT * from Registration WHERE Uname='$uname' OR Mobile_Number='$umobile'";
		
		$rs=mysqli_fetch_array(mysqli_query($conn,$sql));
		
		if(isset($rs))
		{
			echo "User already exist";
		}
		else
		{
        $query = "INSERT into Registration (Uname,Mobile_Number,Password) values ('$uname','$umobile','$upassword')"; 

        $result = mysqli_query($conn,$query);
		        
		if(isset($_POST['Uname']) && $_POST['Mobile_Number'] && $_POST['Password'])
		{ 
			echo "success"; 
		}
		 else
		 { 
			 echo "Registration Failed"; 
          }
		}
    } 
	mysqli_close($conn);
?>