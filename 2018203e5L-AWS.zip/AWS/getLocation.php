<?php 
 
require_once('Connection.php');
		
$sql = "SELECT DISTINCT Location FROM Command";

$r = mysqli_query($conn,$sql);

$result = array();

while($row = mysqli_fetch_array($r)){

 array_push($result,array(

 'Location'=>$row['Location']
 ));

}
echo json_encode(array('result'=>$result));

mysqli_close($conn);
	
?>