<?PHP 
    include_once("Connection.php"); 
    if( isset($_POST['Password']) && isset($_POST['Mobile_Number'])) { 
        $password= $_POST['Password'];
		$mobile=$_POST['Mobile_Number'];
        
        $query = "UPDATE Registration SET Password='$password'". 
        " WHERE Mobile_Number='$mobile'"; 
		
        $result = mysqli_query($conn, $query);
		
            if(isset($_POST['Password']) && $_POST['Mobile_Number']){ 
                echo "success"; 
            }	 
         else{ 
            echo "Login Failed <br/>"; 
        }

    } 
?>